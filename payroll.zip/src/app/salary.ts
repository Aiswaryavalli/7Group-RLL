
export class Salary {
  salId:number;
  empId:number;
  pfAmount:number;
  basicPay:number;
  da:number;
  hra:number;
  grossSalary:number;
  tax:number;
  deduction:number;
  netPay:number;
  tranDate:string;

}
